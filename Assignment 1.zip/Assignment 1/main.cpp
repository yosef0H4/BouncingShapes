#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>




sf::Font load_font(const std::string& font_name)
{
	sf::Font myFont;
	// attempt to load the font from a file
	if (!myFont.loadFromFile(font_name))
	{
		// if we can't load the font, print an error to the error console and exit
		std::cerr << "Could not load font!\n";
		exit(-1);
	}
	else
		return myFont;
}

struct Speed
{
	float x;
	float y;
};
struct Point_of_origin 
{
	float x;
	float y;
};



class Shape 
{
	 sf::Font* m_font= new sf::Font();
	sf::Text m_name;
	sf::Shape* m_shape;
	Speed m_speed;
	Point_of_origin m_origin;
	
	
	
public:
	Shape()
	{

	}

	void set(const sf::Color& text_color,int text_size,  sf::Font* font, const std::string& type,const std::string& name, const float& position_x, const float& position_y, const float& speed_x, const float& speed_y, const sf::Color& color, float width, float height = 0)
	{
		
		if (type == "Circle")
			m_shape = new sf::CircleShape(width);
		else if (type == "Rectangle")
			m_shape = new sf::RectangleShape(sf::Vector2f(width, height));
		else
		{
			std::cout << "cant read shape\n";
			exit(-1);
		}
		
		m_shape->setFillColor(color);
		m_speed.x = speed_x;
		m_speed.y = speed_y;
		m_origin.x = m_shape->getLocalBounds().getSize().x / 2.f;
		m_origin.y = m_shape->getLocalBounds().getSize().y / 2.f;
		m_shape->setOrigin(sf::Vector2f(m_origin.x, m_origin.y));
		m_shape->setPosition(sf::Vector2f(position_x, position_y));
		m_font = font;
		m_name.setFillColor(text_color);
		m_name.setFont(*m_font);
		m_name.setCharacterSize(text_size);
		m_name.setString(name);

		sf::Vector2f Center((m_name.getLocalBounds().getPosition().x * 2 + m_name.getLocalBounds().getSize().x) / 2.f, (m_name.getLocalBounds().getPosition().y * 2 + m_name.getLocalBounds().getSize().y) / 2.f);
		m_name.setOrigin(Center);
	}
	sf::Shape& get_shape() 
	{
		return *m_shape;
	}

	 void draw(sf::RenderWindow &window) 
	{
		 float new_x = m_shape->getPosition().x + m_speed.x;
		 float new_y = m_shape->getPosition().y + m_speed.y;
		m_shape->setPosition(sf::Vector2f(new_x, new_y));
		m_name.setPosition(sf::Vector2f(new_x, new_y));
		if (m_shape->getPosition().x - m_origin.x < 0)
			m_speed.x *= -1;
		else if (m_shape->getPosition().x+m_origin.x > window.getSize().x)
			m_speed.x *= -1;
		else if (m_shape->getPosition().y - m_origin.y < 0)
			m_speed.y *= -1;
		else if (m_shape->getPosition().y + m_origin.y > window.getSize().y)
			m_speed.y *= -1;
		window.draw(*m_shape);
		window.draw(m_name);

	}

	~Shape()
	{
		delete m_shape;
		delete m_font;
	}
};

int count_lines(const std::string& name_of_file)
{
	std::ifstream config(name_of_file);
	int number_of_lines = std::count(std::istreambuf_iterator<char>(config),
		std::istreambuf_iterator<char>(), '\n');
	return number_of_lines;
}

struct loaded
{
	
	int window_width, window_hight;
	Shape* shapes;
	int number_of_shapes;
	sf::Font* font=new sf::Font;  sf::Color font_color; int font_size;


	loaded(const std::string& file_name)
	{
		std::ifstream config(file_name);
		std::string type;
		number_of_shapes = count_lines(file_name) - 2;
		int index = 0;
		shapes = new Shape[number_of_shapes];
		while (config >> type)
		{
			if (type == "Window")
			{
				config >> window_width;	config >> window_hight;
			}
			else if (type == "Font")
			{
				std::string name_font;
				config >> name_font;	
				config >> font_size;
				int r, g, b;
				config >> r; config >> g; config >> b;
				font_color = sf::Color(r, g, b);
				*font = load_font(name_font);

			}
			else if (type == "Circle")
			{
			
			std::string name;
			float position_x;	float position_y;
			float speed_x;		float speed_y;
			int color_r;		int color_g;		int color_b;
			float width;		

			config >> name;
			config >> position_x; config >> position_y;
			config >> speed_x;		config >> speed_y;
			config >> color_r;		config >> color_g;		config >> color_b;
			config >> width;
			sf::Color shape_color(color_r, color_g, color_b);
			
				shapes[index].set(font_color, font_size, font, "Circle", name, position_x, position_y, speed_x, speed_y, shape_color, width);
				index++;
			}
			else if (type == "Rectangle")
			{
				std::string name;
				float position_x;	float position_y;
				float speed_x;		float speed_y;
				int color_r;		int color_g;		int color_b;
				float width;		float height;
				
				config >> name;
				config >> position_x; config >> position_y;
				config >> speed_x;		config >> speed_y;
				config >> color_r;		config >> color_g;		config >> color_b;
				config >> width;		config >> height;
				sf::Color shape_color(color_r, color_g, color_b);

				shapes[index].set(font_color, font_size, font, "Rectangle", name, position_x, position_y, speed_x, speed_y, shape_color, width, height);
				index++;
			}
		}
	}
	
	
	~loaded()
	{
		delete font;
		delete[] shapes;
	}
};


int main(int argc, char* argv[])
{

	loaded config("config.txt");

	sf::RenderWindow window(sf::VideoMode(config.window_width, config.window_hight), "ass 1");
	window.setFramerateLimit(60);

	while (window.isOpen())
	{
		// event handling
		sf::Event event;
		while (window.pollEvent(event))
		{
			// this event triggers when the window is closed
			if (event.type == sf::Event::Closed)

				window.close();



		}
		// basic animation - move the each frame if it's still in frame
		

		// basic rendering function calls
		window.clear();			// clear the window of anything previously drawn
		for (int i=0; i < config.number_of_shapes; i++)
		{
			config.shapes[i].draw(window);
		}
		window.display();		// call the window display function
	}
	return 0;
}